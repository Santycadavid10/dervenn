/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar usuarios */
let template_users = ""
fetch("http://localhost:3000/users")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_users")
    data.forEach(item => {
      template_users += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.lastname}</td>
          <td>${item.email}</td>
          <td>${item.phone}</td>
          <td>
            <a class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#user_edit" onclick="fill('${item.id}')">Editar</a>
            <a class="btn btn-danger btn-sm" onclick="deleteUser('${item.id}')">Eliminar</a>
          </td>
        </tr>
        `
      tbody.innerHTML = template_users;
    })
  })

/* función para eliminar usuarios */
function deleteUser(id) {
  fetch("http://localhost:3000/users/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })

}

/* función para crear usuario */
function createUser() {
  let name = document.getElementById("create_name")
  let lastname = document.getElementById("create_lastname")
  let email = document.getElementById("create_email")
  let phone = document.getElementById("create_phone")

  data_user = {
    name: name.value,
    lastname: lastname.value,
    email: email.value,
    phone: phone.value
  }

  fetch("http://localhost:3000/users", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* funcion para cerrar sesión */
if (localStorage.getItem("auth") == "true") {
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("auth", "")
    location.href = "../html/index.html"
  }
}

/* función para rellenar modal */
function fill(id){
  fetch("http://localhost:3000/users/" + id)
  .then(result => result.json())
  .then(data => {
    document.getElementById("edit_name").value = data.name
    document.getElementById("edit_lastname").value = data.lastname
    document.getElementById("edit_email").value = data.email
    document.getElementById("edit_phone").value = data.phone
    document.getElementById("edit_id").value = data.id
  })
}

/* función para actualizar usuario */
function update(){
  let name = document.getElementById("edit_name")
  let lastname = document.getElementById("edit_lastname")
  let email = document.getElementById("edit_email")
  let phone = document.getElementById("edit_phone")
  let id = document.getElementById("edit_id")

  data_user = {
    name: name.value,
    lastname: lastname.value,
    email: email.value,
    phone: phone.value
  }

  fetch("http://localhost:3000/users/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}
