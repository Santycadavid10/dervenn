/* funcón para verificar super usuario */
function verifySuperUser() {
  let email = document.getElementById("email_login");
  let password = document.getElementById("password_login");

  fetch("http://localhost:3000/super_users")
    .then((result) => result.json())
    .then((data) => {

      let resultado = data.filter(function (element) {
        if(element.email == email.value){
          return element
        }
      });

      if (resultado.length > 0) {
        if (resultado[0].password == password.value) {
          console.log("Correo y contraseñas correctas");
          localStorage.setItem("auth", "true");
          localStorage.setItem("nombre", resultado[0].name);
          location.href = "./../admin/crud_products.html";
        } else {
          console.error("correo o contraseña incorrectos");
        }
      } else {
        console.log("No hay coincidencias");
      }
    });
}
